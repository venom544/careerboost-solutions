const form = document.querySelector('form');
form.addEventListener('submit', function(event) {
  event.preventDefault();
  const name = form.name.value;
  const email = form.email.value;
  const message = form.message.value;

  if (name && email && message) {
    alert('Thank you for your message, we will get back to you shortly!');
    form.reset();
  } else {
    alert('Please fill in all fields.');
  }
});

const slides = document.querySelectorAll(".slide");
let currentSlide = 0;

function showSlide(index) {
  slides[currentSlide].classList.remove("active");
  currentSlide = (index + slides.length) % slides.length;
  slides[currentSlide].classList.add("active");
}

setInterval(() => showSlide(currentSlide + 1), 3000);
